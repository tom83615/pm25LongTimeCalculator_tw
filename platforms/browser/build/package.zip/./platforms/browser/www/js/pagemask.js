$(document).ready(function(){
    $("div.nav").html("<ul>\n" +
                        "\t<li>\n"+
                            "\t\t<a data-icon='"+'edit'+"' href='"+'#pageInpute'+"' data-transition='none'>\n"+
                                "\t\t\t"+'輸入資料'+"\n"+
                            "\t\t</a>\n"+
                        "\t</li>\n"+
                        "\t<li>\n"+
                            "\t\t<a data-icon='"+'cloud'+"' href='"+'#pageShare'+"' data-transition='none'>\n"+
                                "\t\t\t"+'分享 &amp; 儲存'+"\n"+
                            "\t\t</a>\n"+
                        "\t</li>\n"+
                        "\t<li>\n"+
                            "\t\t<a data-icon='"+'info'+"' href='"+'#pageOther'+"' data-transition='none'>\n"+
                                "\t\t\t"+'其他'+"\n"+
                            "\t\t</a>\n"+
                        "\t</li>\n"+
                    "</ul>");
});